2.2.0
-----
- Added support for large integers (> 53 bits) using bigi module
